#!/bin/sh
# Installe Ordo Statisticus pour l'utilisateur courant (sans droits administrateur) :
#   ~/.local/bin/OrdoStatisticus_Battlefield_Overview, icône et entrée dans le menu des applications.
set -e
cd "$(dirname "$0")"
BIN="$HOME/.local/bin"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICONS="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/256x256/apps"
mkdir -p "$BIN" "$APPS" "$ICONS"
install -m 755 OrdoStatisticus_Battlefield_Overview "$BIN/OrdoStatisticus_Battlefield_Overview"
install -m 644 ordo-statisticus.png "$ICONS/ordo-statisticus.png"
sed "s|@BIN@|$BIN/OrdoStatisticus_Battlefield_Overview|" ordo-statisticus.desktop > "$APPS/ordo-statisticus.desktop"
chmod 644 "$APPS/ordo-statisticus.desktop"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS" >/dev/null 2>&1 || true
echo "Installé : $BIN/OrdoStatisticus_Battlefield_Overview"
echo "Lancement : menu des applications > Ordo Statisticus, ou la commande OrdoStatisticus_Battlefield_Overview"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "(ajoutez $BIN à votre PATH pour lancer la commande depuis un terminal)";; esac
