#!/bin/sh
# Désinstalle Ordo Statisticus (les réglages et les parties dans Documents/Ordo Statisticus sont conservés).
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICONS="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/256x256/apps"
rm -f "$HOME/.local/bin/OrdoStatisticus_Battlefield_Overview" "$APPS/ordo-statisticus.desktop" "$ICONS/ordo-statisticus.png"
echo "Ordo Statisticus désinstallé (vos parties sont conservées)."
